// Global variables
let clientsData = [];
let completionChart = null;

// DOM Elements
const clientsTable = document.getElementById('clients-table');
const addClientBtn = document.getElementById('add-client-btn');
const importExcelBtn = document.getElementById('import-excel-btn');
const exportExcelBtn = document.getElementById('export-excel-btn');
const exportPdfBtn = document.getElementById('export-pdf-btn');
const excelFileInput = document.getElementById('excel-file-input');
const saveClientBtn = document.getElementById('save-client-btn');
const progressBar = document.getElementById('progress-bar');
const progressText = document.getElementById('progress-text');

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Load data from localStorage
    loadFromLocalStorage();
    
    // Initialize the chart
    initChart();
    
    // Set up event listeners
    setupEventListeners();
});

// Load data from localStorage
function loadFromLocalStorage() {
    const savedData = localStorage.getItem('clientsData');
    if (savedData) {
        clientsData = JSON.parse(savedData);
        renderTable();
        updateProgressIndicators();
    }
}

// Save data to localStorage
function saveToLocalStorage() {
    localStorage.setItem('clientsData', JSON.stringify(clientsData));
}

// Initialize the chart
function initChart() {
    const ctx = document.getElementById('completion-chart').getContext('2d');
    completionChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Complété', 'En attente'],
            datasets: [{
                data: [0, 0],
                backgroundColor: ['#28a745', '#dc3545'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Set up event listeners
function setupEventListeners() {
    // Add client button
    addClientBtn.addEventListener('click', function() {
        const modal = new bootstrap.Modal(document.getElementById('addClientModal'));
        document.getElementById('add-client-form').reset();
        modal.show();
    });
    
    // Save client button
    saveClientBtn.addEventListener('click', addNewClient);
    
    // Import Excel button
    importExcelBtn.addEventListener('click', function() {
        excelFileInput.click();
    });
    
    // Excel file input change
    excelFileInput.addEventListener('change', importExcel);
    
    // Export Excel button
    exportExcelBtn.addEventListener('click', exportToExcel);
    
    // Export PDF button
    exportPdfBtn.addEventListener('click', exportToPDF);
}

// Render the table with client data
function renderTable() {
    const tbody = clientsTable.querySelector('tbody');
    tbody.innerHTML = '';
    
    clientsData.forEach((client, index) => {
        const row = document.createElement('tr');
        
        // Create cells for each column
        const columns = ['raison_sociale', 'site', 'region', 'localisation', 'ext', 'fait', 'motif', 'no_f1v', 'date_visite', 'gps'];
        
        columns.forEach(column => {
            const cell = document.createElement('td');
            cell.className = 'editable';
            cell.dataset.column = column;
            cell.dataset.index = index;
            
            if (column === 'fait') {
                // Create dropdown for FAIT column
                const select = document.createElement('select');
                select.className = 'form-select form-select-sm';
                
                const emptyOption = document.createElement('option');
                emptyOption.value = '';
                emptyOption.textContent = '';
                
                const ouiOption = document.createElement('option');
                ouiOption.value = 'Oui';
                ouiOption.textContent = 'Oui';
                
                const nonOption = document.createElement('option');
                nonOption.value = 'Non';
                nonOption.textContent = 'Non';
                
                select.appendChild(emptyOption);
                select.appendChild(ouiOption);
                select.appendChild(nonOption);
                
                if (client[column]) {
                    select.value = client[column];
                }
                
                select.addEventListener('change', function() {
                    client[column] = this.value;
                    saveToLocalStorage();
                    updateProgressIndicators();
                });
                
                cell.appendChild(select);
                cell.className = ''; // Remove editable class
            } else {
                // Regular text cell
                cell.textContent = client[column] || '';
                
                // Add click event for inline editing
                cell.addEventListener('click', function() {
                    const currentValue = client[column] || '';
                    const input = document.createElement('input');
                    input.type = column === 'date_visite' ? 'date' : 'text';
                    input.className = 'form-control form-control-sm';
                    input.value = currentValue;
                    
                    cell.textContent = '';
                    cell.appendChild(input);
                    input.focus();
                    
                    // Handle input blur
                    input.addEventListener('blur', function() {
                        client[column] = input.value;
                        cell.textContent = input.value;
                        saveToLocalStorage();
                    });
                    
                    // Handle Enter key
                    input.addEventListener('keypress', function(e) {
                        if (e.key === 'Enter') {
                            client[column] = input.value;
                            cell.textContent = input.value;
                            saveToLocalStorage();
                        }
                    });
                });
            }
            
            row.appendChild(cell);
        });
        
        tbody.appendChild(row);
    });
}

// Add a new client
function addNewClient() {
    const form = document.getElementById('add-client-form');
    const newClient = {
        raison_sociale: form.raison_sociale.value,
        site: form.site.value,
        region: form.region.value,
        localisation: form.localisation.value,
        ext: form.ext.value,
        fait: form.fait.value,
        motif: form.motif.value,
        no_f1v: form.no_f1v.value,
        date_visite: form.date_visite.value,
        gps: form.gps.value
    };
    
    clientsData.push(newClient);
    saveToLocalStorage();
    renderTable();
    updateProgressIndicators();
    
    // Close the modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('addClientModal'));
    modal.hide();
}

// Update progress indicators
function updateProgressIndicators() {
    const totalClients = clientsData.length;
    const completedClients = clientsData.filter(client => client.fait === 'Oui').length;
    const completionPercentage = totalClients > 0 ? Math.round((completedClients / totalClients) * 100) : 0;
    
    // Update progress bar
    progressBar.style.width = `${completionPercentage}%`;
    progressBar.textContent = `${completionPercentage}%`;
    progressBar.setAttribute('aria-valuenow', completionPercentage);
    
    // Update progress text
    progressText.textContent = `${completedClients} sur ${totalClients} tâches complétées`;
    
    // Update chart
    completionChart.data.datasets[0].data = [completedClients, totalClients - completedClients];
    completionChart.update();
}

// Import Excel file
function importExcel(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        
        // Get the first sheet
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        
        // Convert to JSON
        const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1, defval: '' });
        
        // Process the data
        if (jsonData.length > 1) {
            const headers = jsonData[0];
            const newClientsData = [];
            
            for (let i = 1; i < jsonData.length; i++) {
                const row = jsonData[i];
                const client = {};
                
                // Map Excel columns to our data structure
                client.raison_sociale = row[headers.indexOf('RAISON_SOCIALE')] || '';
                client.site = row[headers.indexOf('SITE')] || '';
                client.region = row[headers.indexOf('RÉGION')] || '';
                client.localisation = row[headers.indexOf('LOCALISATION')] || '';
                client.ext = row[headers.indexOf('∑ EXT')] || '';
                client.fait = row[headers.indexOf('FAIT')] || '';
                client.motif = row[headers.indexOf('MOTIF')] || '';
                client.no_f1v = row[headers.indexOf('N° F 1V')] || '';
                client.date_visite = row[headers.indexOf('DATE DE VISITE')] || '';
                client.gps = row[headers.indexOf('GPS')] || '';
                
                newClientsData.push(client);
            }
            
            clientsData = newClientsData;
            saveToLocalStorage();
            renderTable();
            updateProgressIndicators();
            
            alert('Importation réussie!');
        }
    };
    
    reader.readAsArrayBuffer(file);
    event.target.value = ''; // Reset file input
}

// Export to Excel
function exportToExcel() {
    // Prepare the data
    const headers = ['RAISON_SOCIALE', 'SITE', 'RÉGION', 'LOCALISATION', '∑ EXT', 'FAIT', 'MOTIF', 'N° F 1V', 'DATE DE VISITE', 'GPS'];
    const data = [headers];
    
    clientsData.forEach(client => {
        const row = [
            client.raison_sociale || '',
            client.site || '',
            client.region || '',
            client.localisation || '',
            client.ext || '',
            client.fait || '',
            client.motif || '',
            client.no_f1v || '',
            client.date_visite || '',
            client.gps || ''
        ];
        data.push(row);
    });
    
    // Create a worksheet
    const ws = XLSX.utils.aoa_to_sheet(data);
    
    // Create a workbook
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Clients');
    
    // Generate Excel file
    XLSX.writeFile(wb, 'clients_data.xlsx');
}

// Export to PDF
function exportToPDF() {
    // Initialize jsPDF
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('l', 'mm', 'a4'); // Landscape orientation
    
    // Prepare the data
    const headers = [['RAISON_SOCIALE', 'SITE', 'RÉGION', 'LOCALISATION', '∑ EXT', 'FAIT', 'MOTIF', 'N° F 1V', 'DATE DE VISITE', 'GPS']];
    const data = clientsData.map(client => [
        client.raison_sociale || '',
        client.site || '',
        client.region || '',
        client.localisation || '',
        client.ext || '',
        client.fait || '',
        client.motif || '',
        client.no_f1v || '',
        client.date_visite || '',
        client.gps || ''
    ]);
    
    // Add title
    doc.setFontSize(18);
    doc.text('Liste des Clients', 14, 15);
    
    // Add date
    doc.setFontSize(10);
    doc.text(`Exporté le: ${new Date().toLocaleDateString()}`, 14, 22);
    
    // Add progress information
    const totalClients = clientsData.length;
    const completedClients = clientsData.filter(client => client.fait === 'Oui').length;
    const completionPercentage = totalClients > 0 ? Math.round((completedClients / totalClients) * 100) : 0;
    doc.text(`Progression: ${completedClients}/${totalClients} (${completionPercentage}%)`, 14, 28);
    
    // Add table
    doc.autoTable({
        head: headers,
        body: data,
        startY: 35,
        styles: {
            fontSize: 8,
            cellPadding: 2
        },
        headStyles: {
            fillColor: [52, 58, 64],
            textColor: [255, 255, 255]
        },
        columnStyles: {
            0: { cellWidth: 30 },
            1: { cellWidth: 20 },
            2: { cellWidth: 20 },
            3: { cellWidth: 25 },
            4: { cellWidth: 15 },
            5: { cellWidth: 15 },
            6: { cellWidth: 25 },
            7: { cellWidth: 15 },
            8: { cellWidth: 20 },
            9: { cellWidth: 20 }
        }
    });
    
    // Save the PDF
    doc.save('clients_data.pdf');
}